# Component Gallery

This cart is the shared presentation surface for components that live beside or inside `cart/sweatshop`.

## Scaffold

Run the scaffold before making a component. It creates the component file on the normalized gallery surface, creates its story, and registers it with the gallery.

Atoms default to the `Components` group:

```bash
scripts/gallery-component Button
```

Top-level components must declare atom files up front. They default to the `Compositions` group and are rejected if they do not list at least two atom paths:

```bash
scripts/gallery-component MessageComposer \
  cart/sweatshop/components/MessageComposer.tsx \
  --kind top-level \
  --composed-of "cart/sweatshop/components/InputField.tsx,cart/sweatshop/components/SendButton.tsx"
```

This creates:

- `cart/component-gallery/components/button/Button.tsx`
- `cart/component-gallery/stories/button.story.tsx`

It also updates `cart/component-gallery/stories/index.ts`.

An explicit component file can be passed when the component should live somewhere else:

```bash
scripts/gallery-component Button cart/sweatshop/components/Button.tsx
```

The scaffold also accepts an explicit gallery bucket:

```bash
scripts/gallery-component Button --group "Cards & Tiles"
```

Tags can be attached at scaffold time so utility stories like motion helpers are searchable without pretending they are full components:

```bash
scripts/gallery-component UseSpringDemo --tags "hooks,animation"
```

The same scaffold also covers data-contract stories. Data mode creates a schema file, a mock payload, and a gallery entry in `Data Shapes`. Storage is explicit because the gallery surfaces it as part of the contract:

```bash
scripts/gallery-component ChartDemoData \
  --format data \
  --storage "sqlite-document"
```

## Story Shape

Stories register through `stories/index.ts` as `GallerySection[]`. Each section can declare a gallery `group`, a `kind` (`atom` or `top-level`), and for top-level entries a `composedOf` list of repo-relative atom files. Individual stories can also carry `tags` like `hooks` or `animation`.

Component stories still render variants inside the shared `PAGE_SURFACE` from `surface.ts`:

```tsx
import { defineGallerySection, defineGalleryStory } from '../types';
import { MyComponent } from '../components/my-component/MyComponent';

export const mySection = defineGallerySection({
  id: 'shared',
  title: 'Shared',
  group: {
    id: 'compositions',
    title: 'Compositions',
  },
  kind: 'top-level',
  composedOf: [
    'cart/sweatshop/components/InputField.tsx',
    'cart/sweatshop/components/SendButton.tsx',
  ],
  stories: [
    defineGalleryStory({
      id: 'shared/my-component',
      title: 'MyComponent',
      source: 'cart/sweatshop/components/MyComponent.tsx',
      tags: ['hooks', 'animation'],
      variants: [
        {
          id: 'default',
          name: 'Default',
          render: () => <MyComponent />,
        },
      ],
    }),
  ],
});
```

Data-shape stories are for real product contracts and fixture payloads. They do not render a component. They declare a JSON schema, mock data, and the intended storage target so the gallery shows whether the shape is headed for `localstore`, a SQLite document, normalized SQLite tables, a JSON file, or an atomic file-to-DB sync.

```tsx
import { defineGalleryDataStory, defineGallerySection } from '../types';
import { chartDemoData, chartDemoDataSchema } from '../data/chart-demo-data';

export const chartDemoDataSection = defineGallerySection({
  id: 'chart-demo-data',
  title: 'Chart Demo Data',
  group: {
    id: 'data-shapes',
    title: 'Data Shapes',
  },
  stories: [
    defineGalleryDataStory({
      id: 'chart-demo-data/catalog',
      title: 'Chart Demo Data',
      source: 'cart/component-gallery/data/chart-demo-data.ts',
      format: 'data',
      storage: ['sqlite-document'],
      tags: ['data-shape', 'demo-data'],
      schema: chartDemoDataSchema,
      mockData: chartDemoData,
    }),
  ],
});
```

Top-level entries are expected to prove composition instead of being a single pasted demo surface. Keep stories deterministic, self-contained, and built from ReactJIT primitives or existing cart components. Do not use browser DOM APIs in story setup.
