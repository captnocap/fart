const React: any = require('react');
import { Box, Text } from '../../../../runtime/primitives';

export function FileFingerprintWorkbench(props: { initialPath?: string }) {
  return (
    <Box style={{ padding: 12 }}>
      <Text>File Fingerprint Workbench (stub)</Text>
    </Box>
  );
}
