export const AST_SAMPLE_FILES = Array.from({ length: 20 }, (_, i) => ({
  path: `file${i}.ts`,
  selected: false,
  tagColor: '#86efac',
}));
