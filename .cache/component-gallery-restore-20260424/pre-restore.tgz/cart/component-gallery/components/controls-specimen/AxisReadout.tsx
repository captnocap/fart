import { Box, Col, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, Mono } from './controlsSpecimenParts';
import { VerticalText } from './ControlsSpecimenShell';
import { CTRL } from './controlsSpecimenTheme';

export type AxisReadoutBar = {
  label: string;
  value: number;
};

export type AxisReadoutProps = {
  axisLabel?: string;
  bars?: AxisReadoutBar[];
};

const DEFAULT_BARS: AxisReadoutBar[] = [
  { label: 'W·01', value: 48 },
  { label: 'W·02', value: 82 },
  { label: 'W·03', value: 96 },
  { label: 'W·04', value: 22 },
  { label: 'W·05', value: 64 },
  { label: 'W·06', value: 38 },
];

export function AxisReadout({
  axisLabel = 'LOAD · SKEW',
  bars = DEFAULT_BARS,
}: AxisReadoutProps) {
  return (
    <Row style={{ gap: 10, alignItems: 'center' }}>
      <VerticalText text={axisLabel} color={CTRL.inkDimmer} fontSize={8} />
      <AtomFrame width={260} padding={10} gap={8}>
        {bars.map((bar) => (
          <Row key={bar.label} style={{ width: '100%', alignItems: 'center', gap: 8 }}>
            <Mono color={CTRL.inkDimmer} style={{ width: 28 }}>{bar.label}</Mono>
            <Box style={{ flexGrow: 1, flexBasis: 0, height: 6, borderWidth: 1, borderColor: CTRL.rule, backgroundColor: CTRL.bg1 }}>
              <Box style={{ width: `${bar.value}%`, height: 4, backgroundColor: bar.value > 85 ? CTRL.accentHot : CTRL.accent }} />
            </Box>
            <Body fontSize={10} color={CTRL.ink}>{bar.value}%</Body>
          </Row>
        ))}
      </AtomFrame>
    </Row>
  );
}
