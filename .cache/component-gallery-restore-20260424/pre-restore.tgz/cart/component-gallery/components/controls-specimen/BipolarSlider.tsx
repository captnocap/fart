import { Box, Pressable, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, MeterMarks, Mono } from './controlsSpecimenParts';
import { useControllableNumberState, useHorizontalPercentDrag } from './controlsSpecimenInteractions';
import { CTRL } from './controlsSpecimenTheme';

export type BipolarSliderProps = {
  value?: number;
  width?: number;
  label?: string;
  onChange?: (next: number) => void;
};

export function BipolarSlider({
  value = 65,
  width = 240,
  label = 'OFFSET',
  onChange,
}: BipolarSliderProps) {
  const [current, setCurrent] = useControllableNumberState({ value, defaultValue: value, onChange });
  const drag = useHorizontalPercentDrag(current, setCurrent);
  const center = 0.5;
  const left = Math.min(center, drag.ratio);
  const span = Math.abs(drag.ratio - center);
  const tone = drag.ratio >= center ? CTRL.accent : CTRL.flag;

  return (
    <AtomFrame width={width} padding={10} gap={8}>
      <Row style={{ width: '100%', justifyContent: 'space-between', gap: 8 }}>
        <Mono>{label}</Mono>
        <Body fontSize={12}>{current - 50 > 0 ? `+${current - 50}` : `${current - 50}`}</Body>
      </Row>
      <Pressable onMouseDown={drag.begin} onLayout={drag.onLayout} style={{ width: '100%', height: 24, justifyContent: 'center' }}>
        <Box style={{ width: '100%', height: 4, borderWidth: 1, borderColor: CTRL.ruleBright, backgroundColor: CTRL.bg1 }} />
        <Box style={{ position: 'absolute', left: '50%', top: 7, width: 1, height: 10, backgroundColor: CTRL.inkDim }} />
        <Box style={{ position: 'absolute', left: `${left * 100}%`, top: 8, width: `${span * 100}%`, height: 6, backgroundColor: tone }} />
        <Box
          style={{
            position: 'absolute',
            left: `${drag.ratio * 100}%`,
            top: 4,
            width: 8,
            height: 16,
            marginLeft: -4,
            borderWidth: 1,
            borderColor: tone,
            backgroundColor: drag.dragging ? tone : CTRL.bg3,
          }}
        />
      </Pressable>
      <MeterMarks labels={['−50', '−25', '0', '+25', '+50']} />
    </AtomFrame>
  );
}
