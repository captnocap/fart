import { Box, Col, Row } from '../../../../runtime/primitives';
import { Body, Mono } from './controlsSpecimenParts';
import { CTRL } from './controlsSpecimenTheme';

export type ChronologyEvent = {
  ts: string;
  label: string;
  tone?: 'default' | 'flag' | 'current';
};

export type ChronologyTrailProps = {
  events?: ChronologyEvent[];
};

const DEFAULT_EVENTS: ChronologyEvent[] = [
  { ts: '14:02:01', label: 'rat lock · raised' },
  { ts: '14:03:12', label: 'scope · narrowed' },
  { ts: '14:06:44', label: 'operator · active', tone: 'current' },
  { ts: '—', label: 'quarantine · pending' },
];

export function ChronologyTrail({
  events = DEFAULT_EVENTS,
}: ChronologyTrailProps) {
  return (
    <Col style={{ gap: 6 }}>
      {events.map((event, index) => {
        const color = event.tone === 'flag' ? CTRL.flag : event.tone === 'current' ? CTRL.accent : CTRL.inkDim;
        return (
          <Row key={`${event.ts}-${index}`} style={{ gap: 10, alignItems: 'center' }}>
            <Col style={{ alignItems: 'center', gap: 2 }}>
              <Box style={{ width: 1, height: index === 0 ? 2 : 7, backgroundColor: index === 0 ? 'transparent' : CTRL.rule }} />
              <Box style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: color }} />
              <Box style={{ width: 1, height: index === events.length - 1 ? 2 : 7, backgroundColor: index === events.length - 1 ? 'transparent' : CTRL.rule }} />
            </Col>
            <Mono color={CTRL.inkDimmer} style={{ width: 62 }}>{event.ts}</Mono>
            <Body fontSize={11} color={color}>{event.label}</Body>
          </Row>
        );
      })}
    </Col>
  );
}
