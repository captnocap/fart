import { Box, Col, Row, ScrollView } from '../../../../runtime/primitives';
import { ControlsBadgeSpecimen } from './ControlsBadgeSpecimen';
import { ControlsMixedAxisSpecimen } from './ControlsMixedAxisSpecimen';
import { ControlsSelectionSpecimen } from './ControlsSelectionSpecimen';
import { ControlsSliderSpecimen } from './ControlsSliderSpecimen';
import { Body, Mono } from './controlsSpecimenParts';
import { SpecimenPage } from './ControlsSpecimenShell';
import { CTRL } from './controlsSpecimenTheme';

export type ControlsSpecimenProps = {};

export function ControlsSpecimen(_props: ControlsSpecimenProps) {
  return (
    <Box style={{ width: '100%', backgroundColor: CTRL.bg }}>
      <ScrollView showScrollbar={true} style={{ width: '100%', maxHeight: 1800 }}>
        <Row style={{ width: '100%', justifyContent: 'center' }}>
          <Box style={{ width: CTRL.pageWidth, backgroundColor: CTRL.bg }}>
            <SpecimenPage>
              <Col style={{ gap: 10 }}>
                <Row style={{ justifyContent: 'space-between', gap: 12, alignItems: 'flex-start' }}>
                  <Col style={{ gap: 4 }}>
                    <Mono color={CTRL.accent} fontSize={9} fontWeight="bold" letterSpacing={1.8}>
                      S G
                    </Mono>
                    <Body fontSize={30} color={CTRL.ink}>
                      Mixed orientation marginalia
                    </Body>
                  </Col>
                  <Mono color={CTRL.inkDimmer} style={{ textAlign: 'right' }}>
                    marginalia · axis labels · file
                    {'\n'}
                    tabs
                  </Mono>
                </Row>
              </Col>

              <ControlsSliderSpecimen />
              <ControlsSelectionSpecimen />
              <ControlsBadgeSpecimen />
              <ControlsMixedAxisSpecimen />
            </SpecimenPage>
          </Box>
        </Row>
      </ScrollView>
    </Box>
  );
}
