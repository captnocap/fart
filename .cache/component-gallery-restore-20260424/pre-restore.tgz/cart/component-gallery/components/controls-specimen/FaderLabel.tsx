import { Col } from '../../../../runtime/primitives';
import { Body, Mono } from './controlsSpecimenParts';
import { CTRL } from './controlsSpecimenTheme';

export function FaderLabel(props: { label: string; value?: string; accent?: boolean }) {
  return (
    <Col style={{ alignItems: 'center', gap: 2 }}>
      <Body fontSize={11} color={props.accent ? CTRL.accent : CTRL.ink}>
        {props.label}
      </Body>
      {props.value ? <Mono color={CTRL.inkDimmer}>{props.value}</Mono> : null}
    </Col>
  );
}
