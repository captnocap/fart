import { Col, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, Mono, VerticalSpine } from './controlsSpecimenParts';
import { type ControlTone } from './controlsSpecimenTheme';

export type FileTabMeta = {
  label: string;
  value: string;
};

export type FileTabCardProps = {
  leaf?: string;
  title?: string;
  meta?: FileTabMeta[];
  tone?: ControlTone;
};

const DEFAULT_META: FileTabMeta[] = [
  { label: 'OWNER', value: 'core' },
  { label: 'v', value: '2.1' },
  { label: 'TOUCHED', value: '14:02Z' },
];

export function FileTabCard({
  leaf = 'SPEC · 01',
  title = 'Spec anchor · primary controls',
  meta = DEFAULT_META,
  tone = 'accent',
}: FileTabCardProps) {
  return (
    <Row style={{ gap: 8, alignItems: 'stretch' }}>
      <VerticalSpine label={leaf} tone={tone} solid={true} minWidth={28} />
      <AtomFrame width={236} padding={12} gap={8}>
        <Body fontSize={14}>{title}</Body>
        <Row style={{ gap: 12, flexWrap: 'wrap' }}>
          {meta.map((item) => (
            <Col key={item.label} style={{ gap: 2 }}>
              <Mono>{item.label}</Mono>
              <Body fontSize={11}>{item.value}</Body>
            </Col>
          ))}
        </Row>
      </AtomFrame>
    </Row>
  );
}
