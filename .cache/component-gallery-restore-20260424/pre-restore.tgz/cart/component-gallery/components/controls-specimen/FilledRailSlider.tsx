import { Box, Col, Pressable, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, Mono } from './controlsSpecimenParts';
import { useControllableNumberState, useHorizontalPercentDrag } from './controlsSpecimenInteractions';
import { CTRL } from './controlsSpecimenTheme';

export type FilledRailSliderProps = {
  value?: number;
  width?: number;
  label?: string;
  onChange?: (next: number) => void;
};

export function FilledRailSlider({
  value = 45,
  width = 240,
  label = 'DRIVE',
  onChange,
}: FilledRailSliderProps) {
  const [current, setCurrent] = useControllableNumberState({ value, defaultValue: value, onChange });
  const drag = useHorizontalPercentDrag(current, setCurrent);

  return (
    <AtomFrame width={width} padding={10} gap={8}>
      <Row style={{ width: '100%', justifyContent: 'space-between', gap: 8 }}>
        <Mono>{label}</Mono>
        <Body fontSize={12}>{String(current).padStart(2, '0')}</Body>
      </Row>
      <Pressable onMouseDown={drag.begin} onLayout={drag.onLayout} style={{ width: '100%', height: 28, justifyContent: 'center' }}>
        <Box style={{ width: '100%', height: 8, borderWidth: 1, borderColor: CTRL.ruleBright, backgroundColor: CTRL.bg1 }}>
          <Box style={{ width: `${drag.ratio * 100}%`, height: 6, backgroundColor: CTRL.accent }} />
        </Box>
        <Box
          style={{
            position: 'absolute',
            left: `${drag.ratio * 100}%`,
            top: 3,
            width: 10,
            height: 20,
            marginLeft: -5,
            borderWidth: 1,
            borderColor: CTRL.accent,
            backgroundColor: drag.dragging ? CTRL.accentHot : CTRL.bg3,
          }}
        />
      </Pressable>
      <Mono color={CTRL.inkGhost}>{drag.dragging ? 'dragging' : 'filled rail control'}</Mono>
    </AtomFrame>
  );
}
