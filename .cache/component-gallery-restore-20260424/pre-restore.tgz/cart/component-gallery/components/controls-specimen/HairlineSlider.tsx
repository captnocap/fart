import { Box, Col, Pressable, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, MeterMarks, Mono } from './controlsSpecimenParts';
import { useControllableNumberState, useHorizontalPercentDrag } from './controlsSpecimenInteractions';
import { CTRL } from './controlsSpecimenTheme';

export type HairlineSliderProps = {
  value?: number;
  width?: number;
  label?: string;
  onChange?: (next: number) => void;
};

export function HairlineSlider({
  value = 62,
  width = 240,
  label = 'GAIN',
  onChange,
}: HairlineSliderProps) {
  const [current, setCurrent] = useControllableNumberState({ value, defaultValue: value, onChange });
  const drag = useHorizontalPercentDrag(current, setCurrent);

  return (
    <AtomFrame width={width} padding={10} gap={8}>
      <Row style={{ width: '100%', justifyContent: 'space-between', gap: 8 }}>
        <Mono>{label}</Mono>
        <Body fontSize={12}>{String(current).padStart(2, '0')}</Body>
      </Row>
      <Pressable onMouseDown={drag.begin} onLayout={drag.onLayout} style={{ width: '100%', height: 24, justifyContent: 'center' }}>
        <Box style={{ width: '100%', height: 1, backgroundColor: CTRL.rule }} />
        <Box style={{ position: 'absolute', left: 0, top: 11, width: `${drag.ratio * 100}%`, height: 1, backgroundColor: CTRL.accent }} />
        <Box
          style={{
            position: 'absolute',
            left: `${drag.ratio * 100}%`,
            top: 3,
            width: 6,
            height: 18,
            marginLeft: -3,
            borderWidth: 1,
            borderColor: CTRL.accent,
            backgroundColor: drag.dragging ? CTRL.accent : CTRL.bg,
          }}
        />
      </Pressable>
      <MeterMarks labels={['0', '25', '50', '75', '100']} />
    </AtomFrame>
  );
}
