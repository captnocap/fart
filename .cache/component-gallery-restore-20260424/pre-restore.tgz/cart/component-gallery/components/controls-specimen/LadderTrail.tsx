import { Box, Col, Row } from '../../../../runtime/primitives';
import { Body, Mono } from './controlsSpecimenParts';
import { CTRL } from './controlsSpecimenTheme';

export type LadderTrailStep = {
  label: string;
  current?: boolean;
};

export type LadderTrailProps = {
  steps?: LadderTrailStep[];
};

const DEFAULT_STEPS: LadderTrailStep[] = [
  { label: 'intake' },
  { label: 'rewrite' },
  { label: 'verify', current: true },
  { label: 'ship' },
];

export function LadderTrail({
  steps = DEFAULT_STEPS,
}: LadderTrailProps) {
  return (
    <Col style={{ gap: 6 }}>
      {steps.map((step, index) => (
        <Row key={`${step.label}-${index}`} style={{ gap: 8, alignItems: 'center' }}>
          <Col style={{ alignItems: 'center', gap: 2 }}>
            {index > 0 ? <Box style={{ width: 1, height: 8, backgroundColor: CTRL.rule }} /> : <Box style={{ width: 1, height: 2 }} />}
            <Box style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: step.current ? CTRL.accent : CTRL.rule }} />
            {index < steps.length - 1 ? <Box style={{ width: 1, height: 8, backgroundColor: CTRL.rule }} /> : <Box style={{ width: 1, height: 2 }} />}
          </Col>
          <Body fontSize={11} color={step.current ? CTRL.ink : CTRL.inkDim}>{step.label}</Body>
        </Row>
      ))}
      <Mono color={CTRL.inkGhost}>trail chronology</Mono>
    </Col>
  );
}
