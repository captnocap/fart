import { Col, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, Mono, VerticalSpine } from './controlsSpecimenParts';

export type SideSpineCrumbsProps = {
  spineLabel?: string;
  crumbs?: string[];
};

const DEFAULT_CRUMBS = ['cart', 'component-gallery', 'controls-specimen', 'AxisReadout.tsx'];

export function SideSpineCrumbs({
  spineLabel = 'SPEC · FS',
  crumbs = DEFAULT_CRUMBS,
}: SideSpineCrumbsProps) {
  return (
    <Row style={{ gap: 8, alignItems: 'stretch' }}>
      <VerticalSpine label={spineLabel} tone="accent" />
      <AtomFrame width={244} padding={10} gap={6}>
        {crumbs.map((crumb, index) => (
          <Col key={`${crumb}-${index}`} style={{ gap: 2 }}>
            <Mono>{index === 0 ? 'ROOT' : `LEVEL ${index}`}</Mono>
            <Body fontSize={11}>{crumb}</Body>
          </Col>
        ))}
      </AtomFrame>
    </Row>
  );
}
