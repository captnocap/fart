import { Col, Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, Mono, VerticalSpine } from './controlsSpecimenParts';
import { type ControlTone } from './controlsSpecimenTheme';

export type SideTabCardProps = {
  spine: string;
  title: string;
  value: string;
  sub: string;
  tone?: ControlTone;
};

export function SideTabCard({
  spine,
  title,
  value,
  sub,
  tone = 'accent',
}: SideTabCardProps) {
  return (
    <Row style={{ gap: 8, alignItems: 'stretch' }}>
      <VerticalSpine label={spine} tone={tone} />
      <AtomFrame width={220} padding={10} gap={4}>
        <Mono>{title}</Mono>
        <Body fontSize={17}>{value}</Body>
        <Mono>{sub}</Mono>
      </AtomFrame>
    </Row>
  );
}
