import { Col, Row } from '../../../../runtime/primitives';
import { Mono } from './controlsSpecimenParts';
import { CTRL, type ControlTone, toneColor, toneSoftBackground } from './controlsSpecimenTheme';

export type TotemSegment = {
  label: string;
  tone?: ControlTone;
};

export type TotemStackProps = {
  segments: TotemSegment[];
};

export function TotemStack({ segments }: TotemStackProps) {
  return (
    <Col style={{ gap: 4 }}>
      {segments.map((segment, index) => {
        const tone = segment.tone ?? 'neutral';
        return (
          <Row
            key={`${segment.label}-${index}`}
            style={{
              paddingLeft: 8,
              paddingRight: 8,
              paddingTop: 6,
              paddingBottom: 6,
              borderWidth: 1,
              borderColor: tone === 'neutral' ? CTRL.rule : toneColor(tone),
              backgroundColor: tone === 'neutral' ? CTRL.bg1 : toneSoftBackground(tone),
            }}
          >
            <Mono color={tone === 'neutral' ? CTRL.inkDim : toneColor(tone)} fontSize={9} fontWeight="bold">
              {segment.label}
            </Mono>
          </Row>
        );
      })}
    </Col>
  );
}
