import { Row } from '../../../../runtime/primitives';
import { AtomFrame, Body, Mono, VerticalSpine } from './controlsSpecimenParts';

export type UnitRailProps = {
  unit: string;
  value: string;
  sub: string;
};

export function UnitRail({
  unit,
  value,
  sub,
}: UnitRailProps) {
  return (
    <Row style={{ gap: 8, alignItems: 'stretch' }}>
      <VerticalSpine label={unit} tone="accent" />
      <AtomFrame width={216} padding={10} gap={4}>
        <Body fontSize={18}>{value}</Body>
        <Mono>{sub}</Mono>
      </AtomFrame>
    </Row>
  );
}
