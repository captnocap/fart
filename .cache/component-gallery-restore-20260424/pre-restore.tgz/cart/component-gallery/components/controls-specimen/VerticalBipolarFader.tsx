import { Box, Pressable } from '../../../../runtime/primitives';
import { AtomFrame } from './controlsSpecimenParts';
import { FaderLabel } from './FaderLabel';
import { useControllableNumberState, useVerticalPercentDrag } from './controlsSpecimenInteractions';
import { CTRL } from './controlsSpecimenTheme';

export type VerticalBipolarFaderProps = {
  value?: number;
  label?: string;
  onChange?: (next: number) => void;
};

export function VerticalBipolarFader({
  value = 72,
  label = '+22',
  onChange,
}: VerticalBipolarFaderProps) {
  const [current, setCurrent] = useControllableNumberState({ value, defaultValue: value, onChange });
  const drag = useVerticalPercentDrag(current, setCurrent);
  const center = 0.5;
  const lower = Math.min(center, drag.ratio);
  const span = Math.abs(drag.ratio - center);
  const tone = drag.ratio >= center ? CTRL.accent : CTRL.flag;

  return (
    <AtomFrame width={64} padding={10} gap={8}>
      <Pressable onMouseDown={drag.begin} onLayout={drag.onLayout} style={{ width: '100%', height: 132, alignItems: 'center', justifyContent: 'center' }}>
        <Box style={{ width: 14, height: 120, borderWidth: 1, borderColor: CTRL.ruleBright, backgroundColor: CTRL.bg1 }} />
        <Box style={{ position: 'absolute', left: 31, top: 66, width: 14, height: 1, backgroundColor: CTRL.inkDim }} />
        <Box style={{ position: 'absolute', left: 32, bottom: `${lower * 100}%`, width: 12, height: `${span * 100}%`, backgroundColor: tone }} />
        <Box
          style={{
            position: 'absolute',
            left: 21,
            bottom: `${drag.ratio * 100}%`,
            marginBottom: -4,
            width: 34,
            height: 8,
            borderWidth: 1,
            borderColor: tone,
            backgroundColor: drag.dragging ? tone : CTRL.bg3,
          }}
        />
      </Pressable>
      <FaderLabel label={label} accent={true} />
    </AtomFrame>
  );
}
