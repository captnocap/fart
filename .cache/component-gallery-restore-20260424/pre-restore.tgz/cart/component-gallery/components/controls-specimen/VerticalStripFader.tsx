import { Box, Pressable } from '../../../../runtime/primitives';
import { AtomFrame } from './controlsSpecimenParts';
import { FaderLabel } from './FaderLabel';
import { useControllableNumberState, useVerticalPercentDrag } from './controlsSpecimenInteractions';
import { CTRL } from './controlsSpecimenTheme';

export type VerticalStripFaderProps = {
  value?: number;
  label?: string;
  onChange?: (next: number) => void;
};

export function VerticalStripFader({
  value = 72,
  label = '−3',
  onChange,
}: VerticalStripFaderProps) {
  const [current, setCurrent] = useControllableNumberState({ value, defaultValue: value, onChange });
  const drag = useVerticalPercentDrag(current, setCurrent);

  return (
    <AtomFrame width={64} padding={10} gap={8}>
      <Pressable onMouseDown={drag.begin} onLayout={drag.onLayout} style={{ width: '100%', height: 132, alignItems: 'center', justifyContent: 'center' }}>
        <Box style={{ width: 20, height: 120, borderWidth: 1, borderColor: CTRL.ruleBright, backgroundColor: CTRL.bg1 }} />
        {Array.from({ length: 6 }).map((_, index) => (
          <Box key={index} style={{ position: 'absolute', left: 22, top: 18 + index * 18, width: 12, height: 1, backgroundColor: CTRL.rule }} />
        ))}
        <Box style={{ position: 'absolute', left: 27, bottom: 11, width: 10, height: `${drag.ratio * 100}%`, backgroundColor: CTRL.accent }} />
        <Box
          style={{
            position: 'absolute',
            left: 19,
            bottom: `${drag.ratio * 100}%`,
            marginBottom: -5,
            width: 26,
            height: 10,
            borderWidth: 1,
            borderColor: CTRL.accent,
            backgroundColor: drag.dragging ? CTRL.accentHot : CTRL.bg3,
          }}
        />
      </Pressable>
      <FaderLabel label={label} accent={true} />
    </AtomFrame>
  );
}
