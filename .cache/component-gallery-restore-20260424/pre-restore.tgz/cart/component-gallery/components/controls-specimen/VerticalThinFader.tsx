import { Box, Col, Pressable } from '../../../../runtime/primitives';
import { AtomFrame } from './controlsSpecimenParts';
import { FaderLabel } from './FaderLabel';
import { useControllableNumberState, useVerticalPercentDrag } from './controlsSpecimenInteractions';
import { CTRL } from './controlsSpecimenTheme';

export type VerticalThinFaderProps = {
  value?: number;
  label?: string;
  onChange?: (next: number) => void;
};

export function VerticalThinFader({
  value = 72,
  label = 'A',
  onChange,
}: VerticalThinFaderProps) {
  const [current, setCurrent] = useControllableNumberState({ value, defaultValue: value, onChange });
  const drag = useVerticalPercentDrag(current, setCurrent);

  return (
    <AtomFrame width={62} padding={10} gap={8}>
      <Pressable onMouseDown={drag.begin} onLayout={drag.onLayout} style={{ width: '100%', height: 132, alignItems: 'center', justifyContent: 'center' }}>
        <Box style={{ width: 1, height: 120, backgroundColor: CTRL.rule }} />
        <Box style={{ position: 'absolute', left: 25, bottom: 10, width: 1, height: `${drag.ratio * 100}%`, backgroundColor: CTRL.accent }} />
        <Box
          style={{
            position: 'absolute',
            left: 18,
            bottom: `${drag.ratio * 100}%`,
            marginBottom: -3,
            width: 16,
            height: 6,
            borderWidth: 1,
            borderColor: CTRL.accent,
            backgroundColor: drag.dragging ? CTRL.accent : CTRL.bg3,
          }}
        />
      </Pressable>
      <FaderLabel label={label} value={String(current)} accent={true} />
    </AtomFrame>
  );
}
