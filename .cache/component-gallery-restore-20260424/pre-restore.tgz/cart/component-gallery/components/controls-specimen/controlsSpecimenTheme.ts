export const CTRL = {
  pageWidth: 860,
  pagePadding: 24,
  bg: '#0e0b09',
  bg1: '#14100d',
  bg2: '#1a1511',
  bg3: '#221b15',
  ink: '#f2e8dc',
  inkDim: '#b8a890',
  inkDimmer: '#7a6e5d',
  inkGhost: '#4a4238',
  rule: '#3a2a1e',
  ruleBright: '#8a4a20',
  accent: '#d26a2a',
  accentHot: '#e8501c',
  ok: '#6aa390',
  warn: '#d6a54a',
  flag: '#e14a2a',
  lilac: '#8a7fd4',
  blue: '#5a8bd6',
  shadow: 'rgba(210, 106, 42, 0.24)',
  softAccent: 'rgba(210, 106, 42, 0.09)',
  softOk: 'rgba(106, 163, 144, 0.09)',
  softFlag: 'rgba(225, 74, 42, 0.09)',
  mono: 'monospace',
  sans: 'sans-serif',
  cardTallMinHeight: 184,
  cardMinHeight: 144,
  cardWide: 412,
  cardMedium: 274,
  cardNarrow: 205,
} as const;

export type ControlTone =
  | 'default'
  | 'accent'
  | 'ok'
  | 'warn'
  | 'flag'
  | 'blue'
  | 'lilac'
  | 'ink'
  | 'neutral';

export function toneColor(tone: ControlTone = 'default'): string {
  switch (tone) {
    case 'accent':
      return CTRL.accent;
    case 'ok':
      return CTRL.ok;
    case 'warn':
      return CTRL.warn;
    case 'flag':
      return CTRL.flag;
    case 'blue':
      return CTRL.blue;
    case 'lilac':
      return CTRL.lilac;
    case 'ink':
      return CTRL.ink;
    case 'neutral':
      return CTRL.inkDim;
    default:
      return CTRL.ruleBright;
  }
}

export function toneSoftBackground(tone: ControlTone = 'default'): string {
  switch (tone) {
    case 'accent':
      return CTRL.softAccent;
    case 'ok':
      return CTRL.softOk;
    case 'flag':
      return CTRL.softFlag;
    case 'warn':
      return 'rgba(214, 165, 74, 0.1)';
    case 'blue':
      return 'rgba(90, 139, 214, 0.1)';
    case 'lilac':
      return 'rgba(138, 127, 212, 0.1)';
    case 'ink':
      return 'rgba(242, 232, 220, 0.08)';
    default:
      return CTRL.bg2;
  }
}

export function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}
