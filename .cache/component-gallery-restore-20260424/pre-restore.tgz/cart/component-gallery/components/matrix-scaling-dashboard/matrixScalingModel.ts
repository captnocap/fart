export const PANEL_SIZES = [32, 64, 128];

export const LOGICAL_SIZE = 256;

export type Drop = { x: number; y: number; speed: number; brightness: number };

export function createMatrixSimulation(_seed: number) {
  return {
    drops: [] as Drop[],
    tick: () => {},
  };
}
