import { useMemo, useState } from 'react';
import { callHost } from '../../runtime/ffi';
import { Box, Col, Pressable, Row, ScrollView, Text, TextInput } from '../../runtime/primitives';
import { fuzzyScore } from '../sweatshop/components/palette/useFuzzyFilter';
import { gallerySections } from './registry';
import { COLORS, PAGE_SURFACE } from './surface';
import { getDataStoryStorage, getStoryVariants, isDataStory } from './types';
import type {
  GalleryDataStorage,
  GalleryDataStory,
  GalleryGroup,
  GallerySection,
  GallerySectionKind,
  GalleryStory,
  GalleryVariant,
} from './types';

type StoryEntry = {
  section: GallerySection;
  story: GalleryStory;
};

type StoryNavGroup = {
  id: string;
  title: string;
  order: number;
  entries: StoryEntry[];
};

type StoryKindGroup = {
  id: GallerySectionKind;
  title: string;
  groups: StoryNavGroup[];
};

type FilterOption = {
  id: string;
  label: string;
  order?: number;
};

type SearchField = {
  text: string;
  weight: number;
  mode: 'strict' | 'loose';
};

type NavigationFilters = {
  kind: 'all' | GallerySectionKind;
  groupId: 'all' | string;
  tag: 'all' | string;
};

type Selection = {
  storyId: string;
  variantId: string;
};

const FALLBACK_GROUP: GalleryGroup = {
  id: 'components',
  title: 'Components',
  order: 999,
};

const KIND_TITLES: Record<GallerySectionKind, string> = {
  'top-level': 'Top-Level',
  atom: 'Atoms',
};

const TAG_FILTER_PRIORITY: Record<string, number> = {
  hooks: 10,
  animation: 20,
  'theme-system': 30,
  theme: 40,
  palette: 50,
  'data-shape': 60,
  'demo-data': 70,
  'storage:sqlite-document': 80,
  'storage:sqlite-table': 90,
  'storage:json-file': 100,
  'storage:localstore': 110,
  'storage:atomic-file-to-db': 120,
};

const STORAGE_TITLES: Record<GalleryDataStorage, string> = {
  localstore: 'Localstore',
  'sqlite-document': 'SQLite Document',
  'sqlite-table': 'SQLite Table',
  'json-file': 'JSON File',
  'atomic-file-to-db': 'Atomic File -> DB',
};

function flattenStories(sections: GallerySection[]): StoryEntry[] {
  const entries: StoryEntry[] = [];
  for (const section of sections) {
    for (const story of section.stories) {
      entries.push({ section, story });
    }
  }
  return entries;
}

function countVariants(stories: StoryEntry[]): number {
  let total = 0;
  for (const entry of stories) total += getStoryVariants(entry.story).length;
  return total;
}

function countStoriesByKind(stories: StoryEntry[], kind: GallerySectionKind): number {
  let total = 0;
  for (const entry of stories) {
    if (getSectionKind(entry.section) === kind) total += 1;
  }
  return total;
}

function sortStoryEntries(stories: StoryEntry[]): StoryEntry[] {
  const baseTitles = new Set(
    stories
      .map((entry) => entry.story.title.toLowerCase())
      .filter((title) => !title.includes(' '))
  );
  const sortKey = (entry: StoryEntry): string => {
    const title = entry.story.title.toLowerCase();
    const words = title.split(/\s+/);
    const last = words[words.length - 1] || title;
    if (words.length > 1 && baseTitles.has(last)) {
      return `${last} ${words.slice(0, -1).join(' ')}`;
    }
    return title;
  };
  return [...stories].sort((a, b) => {
    const byKey = sortKey(a).localeCompare(sortKey(b));
    return byKey !== 0 ? byKey : a.story.title.localeCompare(b.story.title);
  });
}

function getSourceName(source: string): string {
  const parts = source.split('/');
  return parts[parts.length - 1] || source;
}

function getSourceLabel(source: string): string {
  const base = getSourceName(source).replace(/\.[^.]+$/, '');
  return base.replace(/([a-z0-9])([A-Z])/g, '$1 $2');
}

function getSectionGroup(section: GallerySection): GalleryGroup {
  return section.group || FALLBACK_GROUP;
}

function getSectionKind(section: GallerySection): GallerySectionKind {
  return section.kind || 'atom';
}

function getComposedOf(section: GallerySection): string[] {
  return (section.composedOf || []).map((part) => part.trim()).filter(Boolean);
}

function formatStorageLabel(storage: GalleryDataStorage): string {
  return STORAGE_TITLES[storage] || storage;
}

function getStoryTags(story: GalleryStory): string[] {
  const baseTags = (story.tags || []).map((tag) => tag.trim()).filter(Boolean);
  const storageTags = getDataStoryStorage(story).map((storage) => `storage:${storage}`);
  return [...new Set([...baseTags, ...storageTags])];
}

function formatTagLabel(tag: string): string {
  if (tag.startsWith('storage:')) {
    const storage = tag.slice('storage:'.length) as GalleryDataStorage;
    return `Storage ${formatStorageLabel(storage)}`;
  }
  return tag
    .split(/[^a-zA-Z0-9]+/)
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join(' ');
}

function getStoryFile(entry: StoryEntry): string {
  const storySlug = entry.story.id.split('/')[0] || entry.section.id;
  return `cart/component-gallery/stories/${storySlug}.story.tsx`;
}

function normalizeSearchText(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function pushSearchField(
  fields: SearchField[],
  text: string,
  weight: number,
  mode: 'strict' | 'loose'
): void {
  const trimmed = text.trim();
  if (!trimmed) return;

  fields.push({ text: trimmed, weight, mode });

  const normalized = normalizeSearchText(trimmed);
  if (normalized && normalized !== trimmed.toLowerCase()) {
    fields.push({ text: normalized, weight: weight * 0.96, mode });
  }
}

function getDataStorySearchKeys(story: GalleryStory): string[] {
  if (!isDataStory(story)) return [];

  const schemaKeys =
    story.schema && typeof story.schema === 'object' && !Array.isArray(story.schema)
      ? Object.keys(story.schema)
      : [];
  const propertyKeys =
    story.schema &&
    typeof story.schema === 'object' &&
    !Array.isArray(story.schema) &&
    story.schema.properties &&
    typeof story.schema.properties === 'object' &&
    !Array.isArray(story.schema.properties)
      ? Object.keys(story.schema.properties as Record<string, unknown>)
      : [];
  const mockKeys =
    story.mockData && typeof story.mockData === 'object' && !Array.isArray(story.mockData)
      ? Object.keys(story.mockData as Record<string, unknown>)
      : [];

  return [...new Set([...schemaKeys, ...propertyKeys, ...mockKeys].map((key) => key.trim()).filter(Boolean))];
}

function getSearchFields(entry: StoryEntry): SearchField[] {
  const story = entry.story;
  const group = getSectionGroup(entry.section);
  const kind = getSectionKind(entry.section);
  const storyFile = getStoryFile(entry);
  const fields: SearchField[] = [];

  pushSearchField(fields, story.title, 7, 'loose');
  pushSearchField(fields, entry.section.title, 5.5, 'loose');
  pushSearchField(fields, story.id, 5, 'strict');
  pushSearchField(fields, entry.section.id, 4.5, 'strict');
  pushSearchField(fields, getSourceName(story.source), 4, 'loose');
  pushSearchField(fields, getSourceName(storyFile), 3.5, 'strict');
  pushSearchField(fields, group.title, 3, 'strict');
  pushSearchField(fields, group.id, 2.5, 'strict');
  pushSearchField(fields, kind === 'top-level' ? 'top level' : 'atom', 2.25, 'strict');

  for (const tag of getStoryTags(story)) {
    pushSearchField(fields, tag, 3, 'strict');
  }

  for (const storage of getDataStoryStorage(story)) {
    pushSearchField(fields, formatStorageLabel(storage), 2.5, 'strict');
  }

  for (const variant of getStoryVariants(story)) {
    pushSearchField(fields, variant.name, 2.5, 'loose');
  }

  for (const atomPath of getComposedOf(entry.section)) {
    pushSearchField(fields, getSourceName(atomPath), 2.25, 'strict');
  }

  for (const key of getDataStorySearchKeys(story)) {
    pushSearchField(fields, key, 2, 'strict');
  }

  return fields;
}

function scoreStoryEntry(entry: StoryEntry, query: string): number {
  const rawQuery = query.trim();
  if (!rawQuery) return 1;
  const fields = getSearchFields(entry);
  const normalizedQuery = normalizeSearchText(rawQuery);
  const queries = [...new Set([rawQuery, normalizedQuery].filter(Boolean))];
  let best = 0;

  for (const field of fields) {
    for (const candidate of queries) {
      const score = fuzzyScore(candidate, field.text, field.mode);
      if (score <= 0) continue;
      const weighted = score * field.weight;
      if (weighted > best) best = weighted;
    }
  }

  return best;
}

function collectGroupFilters(stories: StoryEntry[]): FilterOption[] {
  const groups = new Map<string, FilterOption>();
  for (const entry of stories) {
    const group = getSectionGroup(entry.section);
    if (!groups.has(group.id)) {
      groups.set(group.id, {
        id: group.id,
        label: group.title,
        order: group.order ?? 999,
      });
    }
  }

  return [...groups.values()].sort((left, right) => {
    const byOrder = (left.order ?? 999) - (right.order ?? 999);
    return byOrder !== 0 ? byOrder : left.label.localeCompare(right.label);
  });
}

function collectTagFilters(stories: StoryEntry[]): FilterOption[] {
  const tags = new Map<string, FilterOption>();
  for (const entry of stories) {
    for (const tag of getStoryTags(entry.story)) {
      if (!tags.has(tag)) {
        tags.set(tag, {
          id: tag,
          label: formatTagLabel(tag),
          order: TAG_FILTER_PRIORITY[tag] ?? 1000,
        });
      }
    }
  }

  return [...tags.values()].sort((left, right) => {
    const byOrder = (left.order ?? 1000) - (right.order ?? 1000);
    return byOrder !== 0 ? byOrder : left.label.localeCompare(right.label);
  });
}

function filterStoryEntries(stories: StoryEntry[], query: string, filters: NavigationFilters): StoryEntry[] {
  const filtered = stories.filter((entry) => {
    if (filters.kind !== 'all' && getSectionKind(entry.section) !== filters.kind) return false;
    if (filters.groupId !== 'all' && getSectionGroup(entry.section).id !== filters.groupId) return false;
    if (filters.tag !== 'all' && !getStoryTags(entry.story).includes(filters.tag)) return false;
    return true;
  });

  const rawQuery = query.trim();
  if (!rawQuery) return filtered;

  return filtered
    .map((entry) => ({ entry, score: scoreStoryEntry(entry, rawQuery) }))
    .filter((item) => item.score > 0)
    .sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      return left.entry.story.title.localeCompare(right.entry.story.title);
    })
    .map((item) => item.entry);
}

function pickSelection(
  stories: StoryEntry[],
  selection: Selection | null
): { entry: StoryEntry | null; variant: GalleryVariant | null } {
  if (stories.length === 0) return { entry: null, variant: null };

  const entry =
    (selection && stories.find((candidate) => candidate.story.id === selection.storyId)) || stories[0];
  const variants = getStoryVariants(entry.story);
  const variant =
    (selection && variants.find((candidate) => candidate.id === selection.variantId)) ||
    variants[0] ||
    null;

  return { entry, variant };
}

function groupVisibleStories(stories: StoryEntry[]): StoryKindGroup[] {
  const kinds = new Map<GallerySectionKind, { title: string; groups: Map<string, StoryNavGroup> }>();

  for (const entry of stories) {
    const kind = getSectionKind(entry.section);
    const group = getSectionGroup(entry.section);
    let kindBucket = kinds.get(kind);
    if (!kindBucket) {
      kindBucket = {
        title: KIND_TITLES[kind],
        groups: new Map(),
      };
      kinds.set(kind, kindBucket);
    }

    let groupBucket = kindBucket.groups.get(group.id);
    if (!groupBucket) {
      groupBucket = {
        id: group.id,
        title: group.title,
        order: group.order ?? 999,
        entries: [],
      };
      kindBucket.groups.set(group.id, groupBucket);
    }

    groupBucket.entries.push(entry);
  }

  return [...kinds.entries()]
    .sort(([left], [right]) => (left === right ? 0 : left === 'top-level' ? -1 : 1))
    .map(([kind, bucket]) => ({
      id: kind,
      title: bucket.title,
      groups: [...bucket.groups.values()].sort((left, right) => {
        const byOrder = left.order - right.order;
        return byOrder !== 0 ? byOrder : left.title.localeCompare(right.title);
      }),
    }));
}

function windowMinimize() {
  callHost<void>('__window_minimize', undefined as any);
}

function windowMaximize() {
  callHost<void>('__window_maximize', undefined as any);
}

function windowClose() {
  callHost<void>('__window_close', undefined as any);
}

function WindowButton({
  label,
  onPress,
  tone,
}: {
  label: string;
  onPress: () => void;
  tone: string;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        width: 28,
        height: 24,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 6,
        backgroundColor: COLORS.panelBg,
        borderWidth: 1,
        borderColor: COLORS.border,
      }}
    >
      <Text style={{ fontSize: 12, fontWeight: 'bold', color: tone }}>{label}</Text>
    </Pressable>
  );
}

function TitleBar() {
  return (
    <Row
      windowDrag={true}
      style={{
        width: '100%',
        height: 42,
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: 12,
        paddingRight: 8,
        backgroundColor: COLORS.railBg,
        borderBottomWidth: 1,
        borderBottomColor: COLORS.border,
      }}
    >
      <Row style={{ alignItems: 'center', gap: 10, flexGrow: 1, flexBasis: 0 }}>
        <Box
          style={{
            width: 18,
            height: 18,
            borderRadius: 5,
            backgroundColor: COLORS.accent,
            borderWidth: 1,
            borderColor: COLORS.borderStrong,
          }}
        />
        <Col style={{ gap: 1 }}>
          <Text style={{ fontSize: 12, fontWeight: 'bold', color: COLORS.text }}>Component Gallery</Text>
          <Text style={{ fontSize: 9, color: COLORS.faint }}>cart/component-gallery</Text>
        </Col>
      </Row>

      <Row style={{ alignItems: 'center', gap: 6 }}>
        <WindowButton label="-" onPress={windowMinimize} tone={COLORS.warning} />
        <WindowButton label="[]" onPress={windowMaximize} tone={COLORS.success} />
        <WindowButton label="x" onPress={windowClose} tone="#ff7a72" />
      </Row>
    </Row>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <Col
      style={{
        width: 112,
        height: 48,
        justifyContent: 'center',
        paddingLeft: 12,
        paddingRight: 12,
        borderRadius: 8,
        backgroundColor: COLORS.panelBg,
        borderWidth: 1,
        borderColor: COLORS.border,
      }}
    >
      <Text style={{ fontSize: 16, fontWeight: 'bold', color: tone }}>{value}</Text>
      <Text style={{ fontSize: 10, color: COLORS.muted }}>{label}</Text>
    </Col>
  );
}

function NavActionButton({
  label,
  disabled,
  onPress,
}: {
  label: string;
  disabled?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={() => {
        if (!disabled) onPress();
      }}
      style={{
        height: 30,
        flexGrow: 1,
        flexBasis: 0,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 7,
        backgroundColor: disabled ? COLORS.railBg : COLORS.panelBg,
        borderWidth: 1,
        borderColor: disabled ? COLORS.border : COLORS.borderStrong,
      }}
    >
      <Text style={{ fontSize: 10, fontWeight: 'bold', color: disabled ? COLORS.faint : COLORS.text }}>
        {label}
      </Text>
    </Pressable>
  );
}

function FilterChip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        height: 24,
        paddingLeft: 8,
        paddingRight: 8,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 999,
        backgroundColor: active ? COLORS.accent : COLORS.panelBg,
        borderWidth: 1,
        borderColor: active ? COLORS.accent : COLORS.border,
      }}
    >
      <Text style={{ fontSize: 9, fontWeight: 'bold', color: active ? COLORS.accentInk : COLORS.muted }}>
        {label}
      </Text>
    </Pressable>
  );
}

function MetaBadge({
  label,
  tone,
  background,
}: {
  label: string;
  tone: string;
  background: string;
}) {
  return (
    <Box
      style={{
        height: 22,
        paddingLeft: 8,
        paddingRight: 8,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 999,
        backgroundColor: background,
        borderWidth: 1,
        borderColor: tone,
      }}
    >
      <Text style={{ fontSize: 9, fontWeight: 'bold', color: tone }}>{label}</Text>
    </Box>
  );
}

function FilterSection({
  label,
  children,
}: {
  label: string;
  children: any;
}) {
  return (
    <Col style={{ width: '100%', gap: 4 }}>
      <Text style={{ fontSize: 9, fontWeight: 'bold', color: COLORS.faint }}>{label}</Text>
      <Row style={{ width: '100%', gap: 6, flexWrap: 'wrap' }}>{children}</Row>
    </Col>
  );
}

function StoryKindHeader({ title }: { title: string }) {
  return (
    <Text style={{ fontSize: 10, fontWeight: 'bold', color: COLORS.faint }}>
      {title}
    </Text>
  );
}

function StoryNavGroupHeader({
  title,
  count,
  collapsed,
  onPress,
}: {
  title: string;
  count: number;
  collapsed: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        width: '100%',
        minHeight: 36,
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 7,
        paddingBottom: 7,
        borderRadius: 8,
        backgroundColor: COLORS.panelBg,
        borderWidth: 1,
        borderColor: COLORS.border,
      }}
    >
      <Row style={{ width: '100%', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <Col style={{ gap: 1, flexGrow: 1, flexBasis: 0, minWidth: 0 }}>
          <Text style={{ fontSize: 11, fontWeight: 'bold', color: COLORS.text }}>{title}</Text>
          <Text style={{ fontSize: 9, color: COLORS.muted }}>
            {`${count} ${count === 1 ? 'entry' : 'entries'}`}
          </Text>
        </Col>
        <Text style={{ fontSize: 12, fontWeight: 'bold', color: COLORS.faint }}>{collapsed ? '+' : '-'}</Text>
      </Row>
    </Pressable>
  );
}

function StoryNavItem({
  entry,
  active,
  index,
  onPress,
}: {
  entry: StoryEntry;
  active: boolean;
  index: number;
  onPress: () => void;
}) {
  const kind = getSectionKind(entry.section);
  const dataStory = isDataStory(entry.story);
  const kindLabel = dataStory ? 'DATA' : kind === 'top-level' ? 'TOP' : 'ATOM';
  const kindTone = dataStory ? COLORS.success : kind === 'top-level' ? COLORS.warning : COLORS.faint;
  const tagSummary = getStoryTags(entry.story).slice(0, 2).map(formatTagLabel).join(' · ');
  const status = entry.story.status || 'draft';
  const variantCount = getStoryVariants(entry.story).length;
  const detailLabel = dataStory ? 'JSON' : variantCount > 1 ? `${variantCount}v` : status.slice(0, 1).toUpperCase();

  return (
    <Pressable
      onPress={onPress}
      style={{
        width: '100%',
        minHeight: tagSummary ? 42 : 32,
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 4,
        paddingBottom: 4,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 6,
        backgroundColor: active ? COLORS.panelRaised : COLORS.railBg,
        borderWidth: 1,
        borderColor: active ? COLORS.accent : COLORS.border,
      }}
    >
      <Row style={{ width: '100%', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <Col style={{ flexGrow: 1, flexBasis: 0, minWidth: 0 }}>
          <Text
            style={{
              fontSize: 13,
              fontWeight: active ? 'bold' : 'normal',
              color: active ? COLORS.text : COLORS.muted,
            }}
          >
            {entry.story.title}
          </Text>
          {tagSummary ? (
            <Text style={{ fontSize: 8, color: active ? COLORS.accent : COLORS.faint }}>{tagSummary}</Text>
          ) : null}
        </Col>
        <Row style={{ alignItems: 'center', gap: 6 }}>
          <Text
            style={{ width: 22, fontSize: 10, fontWeight: 'bold', color: active ? COLORS.accent : COLORS.faint }}
          >
            {String(index + 1)}
          </Text>
          <Text style={{ width: 30, fontSize: 9, fontWeight: 'bold', color: active ? COLORS.text : kindTone }}>
            {kindLabel}
          </Text>
          <Text
            style={{
              width: 34,
              fontSize: 10,
              fontWeight: dataStory ? 'bold' : 'normal',
              color: dataStory ? COLORS.success : variantCount > 1 ? COLORS.success : COLORS.faint,
            }}
          >
            {detailLabel}
          </Text>
        </Row>
      </Row>
    </Pressable>
  );
}

function VariantButton({
  variant,
  active,
  onPress,
}: {
  variant: GalleryVariant;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        width: 96,
        height: 34,
        paddingLeft: 12,
        paddingRight: 12,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 8,
        backgroundColor: active ? COLORS.accent : COLORS.panelBg,
        borderWidth: 1,
        borderColor: active ? COLORS.accent : COLORS.border,
      }}
    >
      <Text
        style={{
          fontSize: 11,
          fontWeight: 'bold',
          color: active ? COLORS.accentInk : COLORS.text,
        }}
      >
        {variant.name}
      </Text>
    </Pressable>
  );
}

function EmptyPreview() {
  return (
    <Col
      style={{
        flexGrow: 1,
        flexBasis: 0,
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
      }}
    >
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: PAGE_SURFACE.textColor }}>
        No gallery stories registered
      </Text>
      <Text style={{ fontSize: 12, color: PAGE_SURFACE.mutedTextColor }}>cart/component-gallery</Text>
    </Col>
  );
}

function StoryStage({ children }: { children: any }) {
  return (
    <Col
      style={{
        width: '100%',
        minHeight: PAGE_SURFACE.minHeight - PAGE_SURFACE.padding * 2,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {children}
    </Col>
  );
}

function CompositionPanel({
  entry,
  atomStoriesBySource,
  onSelectAtom,
}: {
  entry: StoryEntry;
  atomStoriesBySource: Map<string, StoryEntry>;
  onSelectAtom: (entry: StoryEntry) => void;
}) {
  const kind = getSectionKind(entry.section);
  if (kind !== 'top-level') return null;

  const atoms = getComposedOf(entry.section);
  if (atoms.length === 0) return null;

  return (
    <Col
      style={{
        width: '100%',
        marginTop: 10,
        padding: 10,
        gap: 5,
        borderRadius: 8,
        backgroundColor: COLORS.railBg,
        borderWidth: 1,
        borderColor: COLORS.border,
      }}
    >
      <Text style={{ fontSize: 10, fontWeight: 'bold', color: COLORS.text }}>
        {`Composed of ${atoms.length} atoms`}
      </Text>
      {atoms.map((atomPath) => {
        const atomEntry = atomStoriesBySource.get(atomPath) || null;

        if (!atomEntry) {
          return (
            <Box
              key={atomPath}
              style={{
                width: '100%',
                paddingLeft: 8,
                paddingRight: 8,
                paddingTop: 7,
                paddingBottom: 7,
                gap: 2,
                borderRadius: 6,
                backgroundColor: COLORS.panelBg,
                borderWidth: 1,
                borderColor: COLORS.border,
              }}
            >
              <Text style={{ fontSize: 10, fontWeight: 'bold', color: COLORS.text }}>
                {getSourceLabel(atomPath)}
              </Text>
              <Text style={{ fontSize: 8, color: COLORS.faint }}>{atomPath}</Text>
              <Text style={{ fontSize: 8, color: COLORS.muted }}>No atom page yet</Text>
            </Box>
          );
        }

        return (
          <Pressable
            key={atomPath}
            onPress={() => onSelectAtom(atomEntry)}
            style={{
              width: '100%',
              paddingLeft: 8,
              paddingRight: 8,
              paddingTop: 7,
              paddingBottom: 7,
              gap: 2,
              borderRadius: 6,
              backgroundColor: COLORS.panelBg,
              borderWidth: 1,
              borderColor: COLORS.accent,
            }}
          >
            <Text style={{ fontSize: 10, fontWeight: 'bold', color: COLORS.text }}>
              {atomEntry.story.title}
            </Text>
            <Text style={{ fontSize: 8, color: COLORS.accent }}>{getSourceName(atomPath)}</Text>
            <Text style={{ fontSize: 8, color: COLORS.muted }}>Open atom page</Text>
          </Pressable>
        );
      })}
    </Col>
  );
}

function describeJsonValue(value: unknown): string {
  if (Array.isArray(value)) return `${value.length} ${value.length === 1 ? 'item' : 'items'}`;
  if (value && typeof value === 'object') {
    const count = Object.keys(value as Record<string, unknown>).length;
    return `${count} ${count === 1 ? 'field' : 'fields'}`;
  }
  if (value === null) return 'null';
  return typeof value;
}

function formatJsonPreview(value: unknown): string {
  const rendered = JSON.stringify(value, null, 2);
  return rendered == null ? 'null' : rendered;
}

function JsonDataPanel({
  label,
  tone,
  value,
}: {
  label: string;
  tone: string;
  value: unknown;
}) {
  return (
    <Col
      style={{
        flexGrow: 1,
        flexBasis: 0,
        minWidth: 0,
        gap: 8,
      }}
    >
      <Row style={{ width: '100%', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <Text style={{ fontSize: 11, fontWeight: 'bold', color: tone }}>{label}</Text>
        <Text style={{ fontSize: 9, color: PAGE_SURFACE.mutedTextColor }}>{describeJsonValue(value)}</Text>
      </Row>
      <Box
        style={{
          width: '100%',
          padding: 12,
          borderRadius: 10,
          backgroundColor: COLORS.railBg,
          borderWidth: 1,
          borderColor: COLORS.border,
        }}
      >
        <Text
          style={{
            fontFamily: 'monospace',
            fontSize: 10,
            lineHeight: 16,
            color: PAGE_SURFACE.textColor,
            whiteSpace: 'pre-wrap',
          }}
        >
          {formatJsonPreview(value)}
        </Text>
      </Box>
    </Col>
  );
}

function DataStoryPreview({ story }: { story: GalleryDataStory }) {
  const storage = getDataStoryStorage(story);

  return (
    <Col
      style={{
        width: '100%',
        gap: 16,
        alignItems: 'stretch',
      }}
    >
      {story.summary ? (
        <Text style={{ fontSize: 12, lineHeight: 18, color: PAGE_SURFACE.mutedTextColor }}>{story.summary}</Text>
      ) : null}

      {storage.length > 0 ? (
        <Col
          style={{
            width: '100%',
            padding: 12,
            gap: 8,
            borderRadius: 10,
            backgroundColor: COLORS.railBg,
            borderWidth: 1,
            borderColor: COLORS.border,
          }}
        >
          <Text style={{ fontSize: 10, fontWeight: 'bold', color: COLORS.faint }}>STORAGE TARGET</Text>
          <Row style={{ width: '100%', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            {storage.map((entry) => (
              <MetaBadge
                key={entry}
                label={formatStorageLabel(entry)}
                tone={COLORS.success}
                background={COLORS.panelBg}
              />
            ))}
          </Row>
        </Col>
      ) : null}

      <Row style={{ width: '100%', gap: 16, alignItems: 'flex-start' }}>
        <JsonDataPanel label="JSON Schema" tone={COLORS.warning} value={story.schema} />
        <JsonDataPanel label="Mock Data" tone={COLORS.success} value={story.mockData} />
      </Row>
    </Col>
  );
}

export default function ComponentGalleryApp() {
  const stories = useMemo(() => flattenStories(gallerySections), []);
  const navigationStories = useMemo(() => sortStoryEntries(stories), [stories]);
  const groupFilters = useMemo(() => collectGroupFilters(stories), [stories]);
  const tagFilters = useMemo(() => collectTagFilters(stories), [stories]);
  const variantCount = useMemo(() => countVariants(stories), [stories]);
  const topLevelCount = useMemo(() => countStoriesByKind(stories, 'top-level'), [stories]);
  const [selection, setSelection] = useState<Selection | null>(null);
  const [navQuery, setNavQuery] = useState('');
  const [kindFilter, setKindFilter] = useState<'all' | GallerySectionKind>('all');
  const [groupFilter, setGroupFilter] = useState<'all' | string>('all');
  const [tagFilter, setTagFilter] = useState<'all' | string>('all');
  const [filtersExpanded, setFiltersExpanded] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const filters = useMemo<NavigationFilters>(
    () => ({
      kind: kindFilter,
      groupId: groupFilter,
      tag: tagFilter,
    }),
    [groupFilter, kindFilter, tagFilter]
  );
  const visibleStories = useMemo(
    () => filterStoryEntries(navigationStories, navQuery, filters),
    [filters, navigationStories, navQuery]
  );
  const activeStories = visibleStories.length > 0 ? visibleStories : stories;
  const active = useMemo(() => pickSelection(activeStories, selection), [activeStories, selection]);
  const visibleKindGroups = useMemo(() => groupVisibleStories(visibleStories), [visibleStories]);
  const visibleCategoryCount = useMemo(
    () => visibleKindGroups.reduce((total, kindGroup) => total + kindGroup.groups.length, 0),
    [visibleKindGroups]
  );
  const navIndexes = useMemo(() => {
    const indexes: Record<string, number> = {};
    visibleStories.forEach((entry, index) => {
      indexes[entry.story.id] = index;
    });
    return indexes;
  }, [visibleStories]);
  const atomStoriesBySource = useMemo(() => {
    const entries = new Map<string, StoryEntry>();
    for (const entry of stories) {
      if (getSectionKind(entry.section) !== 'atom') continue;
      if (!entries.has(entry.story.source)) entries.set(entry.story.source, entry);
    }
    return entries;
  }, [stories]);
  const activeNavIndex = active.entry
    ? visibleStories.findIndex((entry) => entry.story.id === active.entry!.story.id)
    : -1;
  const trimmedNavQuery = navQuery.trim();
  const hasActiveFilters = kindFilter !== 'all' || groupFilter !== 'all' || tagFilter !== 'all';
  const activeFilterCount = (kindFilter !== 'all' ? 1 : 0) + (groupFilter !== 'all' ? 1 : 0) + (tagFilter !== 'all' ? 1 : 0);
  const filterSummary = useMemo(() => {
    const parts: string[] = [];
    if (kindFilter !== 'all') parts.push(KIND_TITLES[kindFilter]);
    if (groupFilter !== 'all') {
      const selectedGroup = groupFilters.find((group) => group.id === groupFilter);
      if (selectedGroup) parts.push(selectedGroup.label);
    }
    if (tagFilter !== 'all') {
      const selectedTag = tagFilters.find((tag) => tag.id === tagFilter);
      if (selectedTag) parts.push(selectedTag.label);
    }
    return parts.length > 0 ? parts.join(' · ') : 'Kind, group, and tag';
  }, [groupFilter, groupFilters, kindFilter, tagFilter, tagFilters]);

  const selectStory = (entry: StoryEntry) => {
    const variants = getStoryVariants(entry.story);
    setSelection({
      storyId: entry.story.id,
      variantId: variants[0]?.id || '',
    });
  };

  const navigateStories = (delta: number) => {
    if (visibleStories.length === 0) return;
    const current = activeNavIndex >= 0 ? activeNavIndex : delta > 0 ? -1 : 0;
    const nextIndex = (current + delta + visibleStories.length) % visibleStories.length;
    selectStory(visibleStories[nextIndex]);
  };

  const toggleGroup = (kind: GallerySectionKind, groupId: string) => {
    const key = `${kind}:${groupId}`;
    setCollapsedGroups((current) => ({
      ...current,
      [key]: !current[key],
    }));
  };

  const clearFilters = () => {
    setKindFilter('all');
    setGroupFilter('all');
    setTagFilter('all');
  };

  return (
    <Box style={{ width: '100%', height: '100%', backgroundColor: COLORS.appBg }}>
      <Col style={{ width: '100%', height: '100%' }}>
        <TitleBar />
        <Row
          style={{
            height: 76,
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingLeft: 24,
            paddingRight: 24,
            backgroundColor: COLORS.railBg,
            borderBottomWidth: 1,
            borderBottomColor: COLORS.border,
          }}
        >
          <Col style={{ gap: 4 }}>
            <Text style={{ fontSize: 19, fontWeight: 'bold', color: COLORS.text }}>Component Gallery</Text>
            <Text style={{ fontSize: 11, color: COLORS.muted }}>cart/component-gallery</Text>
          </Col>
          <Row style={{ gap: 10, alignItems: 'center' }}>
            <Metric label="stories" value={String(stories.length)} tone={COLORS.accent} />
            <Metric label="top-level" value={String(topLevelCount)} tone={COLORS.warning} />
            <Metric label="variants" value={String(variantCount)} tone={COLORS.success} />
          </Row>
        </Row>

        <Row style={{ flexGrow: 1, flexBasis: 0 }}>
          <Col
            style={{
              width: 320,
              height: '100%',
              padding: 12,
              gap: 8,
              backgroundColor: COLORS.railBg,
              borderRightWidth: 1,
              borderRightColor: COLORS.border,
            }}
          >
            <Row style={{ alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
              <Col style={{ gap: 2 }}>
                <Text style={{ fontSize: 11, fontWeight: 'bold', color: COLORS.faint }}>NAVIGATION</Text>
                <Text style={{ fontSize: 9, color: COLORS.muted }}>
                  {`${visibleStories.length} of ${stories.length} stories in ${visibleCategoryCount} groups`}
                </Text>
              </Col>
              <Row style={{ width: 130, gap: 6 }}>
                <NavActionButton
                  label="Prev"
                  disabled={visibleStories.length === 0}
                  onPress={() => navigateStories(-1)}
                />
                <NavActionButton
                  label="Next"
                  disabled={visibleStories.length === 0}
                  onPress={() => navigateStories(1)}
                />
              </Row>
            </Row>

            <Row
              style={{
                width: '100%',
                height: 32,
                alignItems: 'center',
                gap: 8,
                paddingLeft: 10,
                paddingRight: 8,
                borderRadius: 8,
                backgroundColor: COLORS.panelBg,
                borderWidth: 1,
                borderColor: COLORS.border,
              }}
            >
              <Text style={{ width: 28, fontSize: 10, fontWeight: 'bold', color: COLORS.faint }}>Find</Text>
              <TextInput
                value={navQuery}
                onChange={setNavQuery}
                onChangeText={setNavQuery}
                placeholder="Search title, tag, group, file, atom, or data key"
                fontSize={12}
                color={COLORS.text}
                style={{
                  flexGrow: 1,
                  flexBasis: 0,
                  minWidth: 0,
                  paddingLeft: 0,
                  paddingRight: 0,
                  backgroundColor: COLORS.panelBg,
                }}
              />
              {navQuery.length > 0 && (
                <Pressable
                  onPress={() => setNavQuery('')}
                  style={{
                    width: 46,
                    height: 24,
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: 6,
                    backgroundColor: COLORS.railBg,
                    borderWidth: 1,
                    borderColor: COLORS.border,
                  }}
                >
                  <Text style={{ fontSize: 9, fontWeight: 'bold', color: COLORS.muted }}>Clear</Text>
                </Pressable>
              )}
            </Row>

            {trimmedNavQuery ? (
              <Text style={{ fontSize: 9, color: COLORS.muted }}>
                {`${visibleStories.length} ${visibleStories.length === 1 ? 'match' : 'matches'} for "${trimmedNavQuery}"`}
              </Text>
            ) : null}

            <Col
              style={{
                width: '100%',
                padding: 10,
                gap: filtersExpanded ? 8 : 6,
                borderRadius: 8,
                backgroundColor: COLORS.panelBg,
                borderWidth: 1,
                borderColor: COLORS.border,
              }}
            >
              <Row style={{ width: '100%', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <Col style={{ gap: 2, flexGrow: 1, flexBasis: 0, minWidth: 0 }}>
                  <Text style={{ fontSize: 10, fontWeight: 'bold', color: COLORS.faint }}>FILTERS</Text>
                  <Text style={{ fontSize: 8, color: hasActiveFilters ? COLORS.accent : COLORS.muted }}>
                    {filterSummary}
                  </Text>
                </Col>
                <Row style={{ alignItems: 'center', gap: 6 }}>
                  {hasActiveFilters && (
                    <Pressable
                      onPress={clearFilters}
                      style={{
                        height: 22,
                        paddingLeft: 8,
                        paddingRight: 8,
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderRadius: 999,
                        backgroundColor: COLORS.railBg,
                        borderWidth: 1,
                        borderColor: COLORS.border,
                      }}
                    >
                      <Text style={{ fontSize: 8, fontWeight: 'bold', color: COLORS.muted }}>
                        {activeFilterCount > 1 ? `Clear ${activeFilterCount}` : 'Clear'}
                      </Text>
                    </Pressable>
                  )}
                  <Pressable
                    onPress={() => setFiltersExpanded((current) => !current)}
                    style={{
                      height: 22,
                      paddingLeft: 8,
                      paddingRight: 8,
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 999,
                      backgroundColor: COLORS.railBg,
                      borderWidth: 1,
                      borderColor: COLORS.border,
                    }}
                  >
                    <Text style={{ fontSize: 8, fontWeight: 'bold', color: COLORS.text }}>
                      {filtersExpanded ? 'Hide' : 'Show'}
                    </Text>
                  </Pressable>
                </Row>
              </Row>

              {filtersExpanded && (
                <Col style={{ width: '100%', gap: 8 }}>
                  <FilterSection label="Kind">
                    <FilterChip label="All" active={kindFilter === 'all'} onPress={() => setKindFilter('all')} />
                    <FilterChip
                      label="Top-Level"
                      active={kindFilter === 'top-level'}
                      onPress={() => setKindFilter('top-level')}
                    />
                    <FilterChip label="Atoms" active={kindFilter === 'atom'} onPress={() => setKindFilter('atom')} />
                  </FilterSection>

                  <FilterSection label="Group">
                    <FilterChip label="All" active={groupFilter === 'all'} onPress={() => setGroupFilter('all')} />
                    {groupFilters.map((group) => (
                      <FilterChip
                        key={group.id}
                        label={group.label}
                        active={groupFilter === group.id}
                        onPress={() => setGroupFilter(group.id)}
                      />
                    ))}
                  </FilterSection>

                  {tagFilters.length > 0 && (
                    <FilterSection label="Tag">
                      <FilterChip label="All" active={tagFilter === 'all'} onPress={() => setTagFilter('all')} />
                      {tagFilters.map((tag) => (
                        <FilterChip
                          key={tag.id}
                          label={tag.label}
                          active={tagFilter === tag.id}
                          onPress={() => setTagFilter(tag.id)}
                        />
                      ))}
                    </FilterSection>
                  )}
                </Col>
              )}
            </Col>

            {stories.length === 0 ? (
              <Box
                style={{
                  padding: 12,
                  borderRadius: 8,
                  backgroundColor: COLORS.panelBg,
                  borderWidth: 1,
                  borderColor: COLORS.border,
                }}
              >
                <Text style={{ fontSize: 12, color: COLORS.muted }}>No stories yet</Text>
              </Box>
            ) : visibleStories.length === 0 ? (
              <Box
                style={{
                  padding: 12,
                  borderRadius: 8,
                  backgroundColor: COLORS.panelBg,
                  borderWidth: 1,
                  borderColor: COLORS.border,
                }}
              >
                <Text style={{ fontSize: 12, fontWeight: 'bold', color: COLORS.text }}>No matches</Text>
                <Text style={{ fontSize: 10, color: COLORS.muted }}>{navQuery}</Text>
              </Box>
            ) : (
              <ScrollView style={{ width: '100%', flexGrow: 1, flexBasis: 0 }}>
                <Col style={{ width: '100%', gap: 8 }}>
                  {visibleKindGroups.map((kindGroup) => (
                    <Col key={kindGroup.id} style={{ width: '100%', gap: 4 }}>
                      <StoryKindHeader title={kindGroup.title} />
                      {kindGroup.groups.map((group) => {
                        const groupKey = `${kindGroup.id}:${group.id}`;
                        const hasActiveStory = group.entries.some(
                          (entry) => entry.story.id === active.entry?.story.id
                        );
                        const collapsed = navQuery.length === 0 && !hasActiveStory && !!collapsedGroups[groupKey];

                        return (
                          <Col key={groupKey} style={{ width: '100%', gap: 3 }}>
                            <StoryNavGroupHeader
                              title={group.title}
                              count={group.entries.length}
                              collapsed={collapsed}
                              onPress={() => toggleGroup(kindGroup.id, group.id)}
                            />
                            {!collapsed && (
                              <Col style={{ width: '100%', gap: 3, paddingLeft: 10 }}>
                                {group.entries.map((entry) => (
                                  <StoryNavItem
                                    key={entry.story.id}
                                    entry={entry}
                                    active={active.entry?.story.id === entry.story.id}
                                    index={navIndexes[entry.story.id] ?? 0}
                                    onPress={() => selectStory(entry)}
                                  />
                                ))}
                              </Col>
                            )}
                          </Col>
                        );
                      })}
                    </Col>
                  ))}
                </Col>
              </ScrollView>
            )}
          </Col>

          <Col style={{ flexGrow: 1, flexBasis: 0, minWidth: 0 }}>
            <Col
              style={{
                minHeight: 74,
                justifyContent: 'center',
                paddingLeft: 18,
                paddingRight: 18,
                paddingTop: 8,
                paddingBottom: 8,
                backgroundColor: COLORS.panelBg,
                borderBottomWidth: 1,
                borderBottomColor: COLORS.border,
              }}
            >
              <Col style={{ gap: 3, width: '100%' }}>
                <Text style={{ fontSize: 14, fontWeight: 'bold', color: COLORS.text }}>
                  {active.entry ? active.entry.story.title : PAGE_SURFACE.label}
                </Text>
                <Text style={{ fontSize: 10, color: COLORS.muted }}>
                  {active.entry ? active.entry.story.source : 'cart/component-gallery'}
                </Text>
                {active.entry && (
                  <Row
                    style={{
                      width: '100%',
                      gap: 8,
                      marginTop: 6,
                      alignItems: 'center',
                      flexWrap: 'wrap',
                    }}
                  >
                    <MetaBadge
                      label={isDataStory(active.entry.story) ? 'Data Shape' : KIND_TITLES[getSectionKind(active.entry.section)]}
                      tone={
                        isDataStory(active.entry.story)
                          ? COLORS.success
                          : getSectionKind(active.entry.section) === 'top-level'
                            ? COLORS.warning
                            : COLORS.text
                      }
                      background={
                        isDataStory(active.entry.story)
                          ? COLORS.railBg
                          : getSectionKind(active.entry.section) === 'top-level'
                          ? COLORS.panelRaised
                          : COLORS.railBg
                      }
                    />
                    <MetaBadge
                      label={getSectionGroup(active.entry.section).title}
                      tone={COLORS.accent}
                      background={COLORS.railBg}
                    />
                    {getDataStoryStorage(active.entry.story).map((storage) => (
                      <MetaBadge
                        key={storage}
                        label={formatStorageLabel(storage)}
                        tone={COLORS.success}
                        background={COLORS.railBg}
                      />
                    ))}
                    {getStoryTags(active.entry.story)
                      .filter((tag) => !tag.startsWith('storage:'))
                      .map((tag) => (
                        <MetaBadge
                          key={tag}
                          label={formatTagLabel(tag)}
                          tone={tag === 'hooks' ? COLORS.success : COLORS.muted}
                          background={COLORS.railBg}
                        />
                      ))}
                    {getSectionKind(active.entry.section) === 'top-level' && (
                      <Text style={{ fontSize: 10, color: COLORS.muted }}>
                        {`${getComposedOf(active.entry.section).length} atom references`}
                      </Text>
                    )}
                  </Row>
                )}
              </Col>

              {active.entry && (
                <CompositionPanel
                  entry={active.entry}
                  atomStoriesBySource={atomStoriesBySource}
                  onSelectAtom={selectStory}
                />
              )}

              {active.entry && getStoryVariants(active.entry.story).length > 1 && (
                <Row style={{ width: '100%', gap: 8, marginTop: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  {getStoryVariants(active.entry.story).map((variant) => (
                    <VariantButton
                      key={variant.id}
                      variant={variant}
                      active={active.variant?.id === variant.id}
                      onPress={() =>
                        setSelection({
                          storyId: active.entry!.story.id,
                          variantId: variant.id,
                        })
                      }
                    />
                  ))}
                </Row>
              )}
            </Col>

            <ScrollView
              style={{
                flexGrow: 1,
                flexBasis: 0,
                backgroundColor: COLORS.previewBg,
              }}
              showScrollbar
            >
              <Box
                style={{
                  width: '100%',
                  minHeight: 760,
                  alignItems: 'center',
                  padding: 28,
                }}
              >
                <Box
                  style={{
                    width: PAGE_SURFACE.width,
                    minHeight: PAGE_SURFACE.minHeight,
                    padding: PAGE_SURFACE.padding,
                    borderRadius: PAGE_SURFACE.radius,
                    backgroundColor: PAGE_SURFACE.backgroundColor,
                    borderWidth: 1,
                    borderColor: PAGE_SURFACE.borderColor,
                  }}
                >
                  {active.entry ? (
                    isDataStory(active.entry.story) ? (
                      <DataStoryPreview story={active.entry.story} />
                    ) : (
                      <StoryStage>{active.variant ? active.variant.render() : <EmptyPreview />}</StoryStage>
                    )
                  ) : (
                    <StoryStage>
                      <EmptyPreview />
                    </StoryStage>
                  )}
                </Box>
              </Box>
            </ScrollView>
          </Col>
        </Row>
      </Col>
    </Box>
  );
}
