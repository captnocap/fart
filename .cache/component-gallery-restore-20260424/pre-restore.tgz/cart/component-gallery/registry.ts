import type { GalleryGroup, GallerySection, GallerySectionKind } from './types';
import { storySections } from './stories';

const GROUPS = {
  compositions: { id: 'compositions', title: 'Compositions', order: 10 },
  themes: { id: 'themes', title: 'Theme Systems', order: 20 },
  effects: { id: 'effects', title: 'Effect Systems', order: 30 },
  cards: { id: 'cards', title: 'Cards & Tiles', order: 40 },
  indicators: { id: 'indicators', title: 'Indicators & Motion', order: 50 },
  charts: { id: 'charts', title: 'Charts & Data', order: 60 },
  data: { id: 'data-shapes', title: 'Data Shapes', order: 70 },
  components: { id: 'components', title: 'Components', order: 80 },
} satisfies Record<string, GalleryGroup>;

type SectionMeta = {
  group: GalleryGroup;
  kind?: GallerySectionKind;
  composedOf?: string[];
};

const SECTION_META: Record<string, SectionMeta> = {
  'generic-chat-card': {
    group: GROUPS.compositions,
    kind: 'top-level',
    composedOf: [
      'cart/component-gallery/components/generic-chat-card/ConsoleHeader.tsx',
      'cart/component-gallery/components/generic-chat-card/TranscriptFlow.tsx',
      'cart/component-gallery/components/generic-chat-card/TelemetryStats.tsx',
      'cart/component-gallery/components/generic-chat-card/TaskPanel.tsx',
    ],
  },
  'sweatshop-matrix-display': {
    group: GROUPS.effects,
    kind: 'top-level',
    composedOf: [
      'cart/component-gallery/components/sweatshop-matrix-display/BrailleEffectInstrument.tsx',
      'cart/component-gallery/components/sweatshop-matrix-display/BrailleProjectionSurface.tsx',
    ],
  },
  'matrix-scaling-dashboard': { group: GROUPS.effects },
  'model-card': { group: GROUPS.cards },
  'generic-card': { group: GROUPS.cards },
  'skeleton-tiles': { group: GROUPS.cards },
  progress: { group: GROUPS.indicators },
  'circular-progress': { group: GROUPS.indicators },
  tracking: { group: GROUPS.indicators },
  easings: { group: GROUPS.indicators },
  'grid-spinners': { group: GROUPS.indicators },
  'console-header': { group: GROUPS.cards },
  'transcript-flow': { group: GROUPS.cards },
  'telemetry-stats': { group: GROUPS.cards },
  'task-panel': { group: GROUPS.cards },
  'braille-graph': { group: GROUPS.charts },
  'bar-chart': { group: GROUPS.charts },
  surplus: { group: GROUPS.charts },
  'diverging-chart': { group: GROUPS.charts },
  heatmap: { group: GROUPS.charts },
  'pictorial-fraction-chart': { group: GROUPS.charts },
  'contour-map': { group: GROUPS.charts },
  boxplot: { group: GROUPS.charts },
  scatterplot: { group: GROUPS.charts },
  'population-pyramid': { group: GROUPS.charts },
  'proportion-filters': { group: GROUPS.charts },
  'fraction-chart': { group: GROUPS.charts },
  radar: { group: GROUPS.charts },
  candlestick: { group: GROUPS.charts },
  'area-chart': { group: GROUPS.charts },
  'pyramid-chart': { group: GROUPS.charts },
  timeline: { group: GROUPS.charts },
  'combination-chart': { group: GROUPS.charts },
  'fan-chart': { group: GROUPS.charts },
  'waterfall-chart': { group: GROUPS.charts },
  'network-scheme': { group: GROUPS.charts },
  'circular-bar-chart': { group: GROUPS.charts },
  'layered-pyramid': { group: GROUPS.charts },
  'grouped-bar-chart': { group: GROUPS.charts },
  'polar-chart': { group: GROUPS.charts },
  'donut-bar-chart': { group: GROUPS.charts },
  'rings-in-pie-chart': { group: GROUPS.charts },
  'bubble-scatterplot': { group: GROUPS.charts },
  'bubble-correlation': { group: GROUPS.charts },
  'spline-graph': { group: GROUPS.charts },
  'flow-map': { group: GROUPS.charts },
  venn: { group: GROUPS.charts },
  'chart-demo-data': { group: GROUPS.data },
  'braille-effect-instrument': { group: GROUPS.effects },
  'braille-projection-surface': { group: GROUPS.effects },
};

const DEFAULT_GROUP = GROUPS.components;
const DEFAULT_KIND: GallerySectionKind = 'atom';

function pathExists(path: string): boolean {
  const host = globalThis as { __fs_exists?: (target: string) => boolean };
  return typeof host.__fs_exists === 'function' ? !!host.__fs_exists(path) : true;
}

function normalizeSection(section: GallerySection): GallerySection {
  const meta = SECTION_META[section.id];
  return {
    ...section,
    group: section.group || meta?.group || DEFAULT_GROUP,
    kind: section.kind || meta?.kind || DEFAULT_KIND,
    composedOf: section.composedOf || meta?.composedOf,
  };
}

function validateTopLevelSection(section: GallerySection) {
  if (section.kind !== 'top-level') return;

  const atoms = (section.composedOf || []).map((part) => part.trim()).filter(Boolean);
  if (atoms.length < 2) {
    throw new Error(
      `[component-gallery] top-level section "${section.id}" must declare at least two atom paths in composedOf`
    );
  }

  const sourceSet = new Set(section.stories.map((story) => story.source));
  for (const atomPath of atoms) {
    if (sourceSet.has(atomPath)) {
      throw new Error(
        `[component-gallery] top-level section "${section.id}" cannot list its own story source in composedOf`
      );
    }
    if (!pathExists(atomPath)) {
      throw new Error(
        `[component-gallery] top-level section "${section.id}" references missing atom "${atomPath}"`
      );
    }
  }
}

const normalizedSections = storySections.map(normalizeSection);
normalizedSections.forEach(validateTopLevelSection);

export const gallerySections: GallerySection[] = normalizedSections;
