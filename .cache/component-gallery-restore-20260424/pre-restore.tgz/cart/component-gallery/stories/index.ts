import type { GallerySection } from '../types';

import { brailleGraphSection } from './braille-graph.story';
import { barChartSection } from './bar-chart.story';
import { surplusSection } from './surplus.story';
import { divergingChartSection } from './diverging-chart.story';
import { heatmapSection } from './heatmap.story';
import { pictorialFractionChartSection } from './pictorial-fraction-chart.story';
import { contourMapSection } from './contour-map.story';
import { boxplotSection } from './boxplot.story';
import { scatterplotSection } from './scatterplot.story';
import { populationPyramidSection } from './population-pyramid.story';
import { proportionFiltersSection } from './proportion-filters.story';
import { progressSection } from './progress.story';
import { fractionChartSection } from './fraction-chart.story';
import { radarSection } from './radar.story';
import { candlestickSection } from './candlestick.story';
import { areaChartSection } from './area-chart.story';
import { pyramidChartSection } from './pyramid-chart.story';
import { timelineSection } from './timeline.story';
import { combinationChartSection } from './combination-chart.story';
import { fanChartSection } from './fan-chart.story';
import { waterfallChartSection } from './waterfall-chart.story';
import { networkSchemeSection } from './network-scheme.story';
import { trackingSection } from './tracking.story';
import { circularBarChartSection } from './circular-bar-chart.story';
import { processCircleSection } from './process-circle.story';
import { layeredPyramidSection } from './layered-pyramid.story';
import { groupedBarChartSection } from './grouped-bar-chart.story';
import { polarChartSection } from './polar-chart.story';
import { donutBarChartSection } from './donut-bar-chart.story';
import { ringsInPieChartSection } from './rings-in-pie-chart.story';
import { circularProgressSection } from './circular-progress.story';
import { bubbleScatterplotSection } from './bubble-scatterplot.story';
import { bubbleCorrelationSection } from './bubble-correlation.story';
import { splineGraphSection } from './spline-graph.story';
import { flowMapSection } from './flow-map.story';
import { vennSection } from './venn.story';
import { genericCardSection } from './generic-card.story';
import { genericChatCardSection } from './generic-chat-card.story';
import { consoleHeaderSection } from './console-header.story';
import { transcriptFlowSection } from './transcript-flow.story';
import { telemetryStatsSection } from './telemetry-stats.story';
import { taskPanelSection } from './task-panel.story';
import { modelCardSection } from './model-card.story';
import { skeletonTilesSection } from './skeleton-tiles.story';
import { matrixScalingDashboardSection } from './matrix-scaling-dashboard.story';
import { sweatshopMatrixDisplaySection } from './sweatshop-matrix-display.story';
import { brailleEffectInstrumentSection } from './braille-effect-instrument.story';
import { brailleProjectionSurfaceSection } from './braille-projection-surface.story';
import { astQuiltSection } from './ast-quilt.story';
import { controlsSpecimenSection } from './controls-specimen.story';
import { easingsSection } from './easings.story';
import { gridSpinnersSection } from './grid-spinners.story';
import { hairlineSliderSection } from './hairline-slider.story';
import { filledRailSliderSection } from './filled-rail-slider.story';
import { discreteSliderSection } from './discrete-slider.story';
import { bipolarSliderSection } from './bipolar-slider.story';
import { rangeSliderSection } from './range-slider.story';
import { stepSliderSection } from './step-slider.story';
import { meterSliderSection } from './meter-slider.story';
import { verticalThinFaderSection } from './vertical-thin-fader.story';
import { verticalNotchFaderSection } from './vertical-notch-fader.story';
import { verticalStripFaderSection } from './vertical-strip-fader.story';
import { verticalBipolarFaderSection } from './vertical-bipolar-fader.story';
import { choiceListSection } from './choice-list.story';
import { segmentedControlSection } from './segmented-control.story';
import { diodeSelectorSection } from './diode-selector.story';
import { stackSelectorSection } from './stack-selector.story';
import { keycapSelectorSection } from './keycap-selector.story';
import { pipeSelectorSection } from './pipe-selector.story';
import { statusBadgeSection } from './status-badge.story';
import { keyValueBadgeSection } from './key-value-badge.story';
import { bracketBadgeSection } from './bracket-badge.story';
import { tierBadgeSection } from './tier-badge.story';
import { countBadgeSection } from './count-badge.story';
import { stripBadgeSection } from './strip-badge.story';
import { cautionBadgeSection } from './caution-badge.story';
import { metricBadgeSection } from './metric-badge.story';
import { verticalBadgeSection } from './vertical-badge.story';
import { glyphStackBadgeSection } from './glyph-stack-badge.story';
import { sideTabCardSection } from './side-tab-card.story';
import { unitRailSection } from './unit-rail.story';
import { totemStackSection } from './totem-stack.story';
import { verticalCautionBadgeSection } from './vertical-caution-badge.story';
import { prefixDataCardSection } from './prefix-data-card.story';
import { specColumnSection } from './spec-column.story';
import { ladderTrailSection } from './ladder-trail.story';
import { sideSpineCrumbsSection } from './side-spine-crumbs.story';
import { tabularHierarchySection } from './tabular-hierarchy.story';
import { chronologyTrailSection } from './chronology-trail.story';
import { marginaliaPanelSection } from './marginalia-panel.story';
import { axisReadoutSection } from './axis-readout.story';
import { fileTabCardSection } from './file-tab-card.story';
import { scaleLabelCardSection } from './scale-label-card.story';
// component-gallery:imports

export const storySections: GallerySection[] = [
  brailleGraphSection,
  barChartSection,
  surplusSection,
  divergingChartSection,
  heatmapSection,
  pictorialFractionChartSection,
  contourMapSection,
  boxplotSection,
  scatterplotSection,
  populationPyramidSection,
  proportionFiltersSection,
  progressSection,
  fractionChartSection,
  radarSection,
  candlestickSection,
  areaChartSection,
  pyramidChartSection,
  timelineSection,
  combinationChartSection,
  fanChartSection,
  waterfallChartSection,
  networkSchemeSection,
  trackingSection,
  circularBarChartSection,
  processCircleSection,
  layeredPyramidSection,
  groupedBarChartSection,
  polarChartSection,
  donutBarChartSection,
  ringsInPieChartSection,
  circularProgressSection,
  bubbleScatterplotSection,
  bubbleCorrelationSection,
  splineGraphSection,
  flowMapSection,
  vennSection,
  genericCardSection,
  genericChatCardSection,
  consoleHeaderSection,
  transcriptFlowSection,
  telemetryStatsSection,
  taskPanelSection,
  modelCardSection,
  skeletonTilesSection,
  matrixScalingDashboardSection,
  sweatshopMatrixDisplaySection,
  brailleEffectInstrumentSection,
  brailleProjectionSurfaceSection,
  astQuiltSection,
  controlsSpecimenSection,
  easingsSection,
  gridSpinnersSection,
  hairlineSliderSection,
  filledRailSliderSection,
  discreteSliderSection,
  bipolarSliderSection,
  rangeSliderSection,
  stepSliderSection,
  meterSliderSection,
  verticalThinFaderSection,
  verticalNotchFaderSection,
  verticalStripFaderSection,
  verticalBipolarFaderSection,
  choiceListSection,
  segmentedControlSection,
  diodeSelectorSection,
  stackSelectorSection,
  keycapSelectorSection,
  pipeSelectorSection,
  statusBadgeSection,
  keyValueBadgeSection,
  bracketBadgeSection,
  tierBadgeSection,
  countBadgeSection,
  stripBadgeSection,
  cautionBadgeSection,
  metricBadgeSection,
  verticalBadgeSection,
  glyphStackBadgeSection,
  sideTabCardSection,
  unitRailSection,
  totemStackSection,
  verticalCautionBadgeSection,
  prefixDataCardSection,
  specColumnSection,
  ladderTrailSection,
  sideSpineCrumbsSection,
  tabularHierarchySection,
  chronologyTrailSection,
  marginaliaPanelSection,
  axisReadoutSection,
  fileTabCardSection,
  scaleLabelCardSection,
  // component-gallery:sections
];
