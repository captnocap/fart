import type { ReactNode } from 'react';

export type GalleryStoryStatus = 'draft' | 'ready' | 'deprecated';
export type GalleryStoryFormat = 'component' | 'data';
export type GalleryDataStorage =
  | 'localstore'
  | 'sqlite-document'
  | 'sqlite-table'
  | 'json-file'
  | 'atomic-file-to-db';

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
export type JsonObject = {
  [key: string]: JsonValue;
};

export type GalleryGroup = {
  id: string;
  title: string;
  order?: number;
};

export type GallerySectionKind = 'atom' | 'top-level';

export type GalleryVariant = {
  id: string;
  name: string;
  render: () => ReactNode;
  summary?: string;
};

export type GalleryStoryBase = {
  id: string;
  title: string;
  source: string;
  summary?: string;
  owner?: string;
  status?: GalleryStoryStatus;
  tags?: string[];
};

export type GalleryComponentStory = GalleryStoryBase & {
  format?: 'component';
  variants: GalleryVariant[];
};

export type GalleryDataStory = GalleryStoryBase & {
  format: 'data';
  storage: GalleryDataStorage[];
  schema: JsonObject;
  mockData: JsonValue;
};

export type GalleryStory = GalleryComponentStory | GalleryDataStory;

export type GallerySection = {
  id: string;
  title: string;
  group?: GalleryGroup;
  kind?: GallerySectionKind;
  composedOf?: string[];
  stories: GalleryStory[];
};

export function isDataStory(story: GalleryStory): story is GalleryDataStory {
  return story.format === 'data';
}

export function getStoryVariants(story: GalleryStory): GalleryVariant[] {
  return isDataStory(story) ? [] : story.variants;
}

export function getDataStoryStorage(story: GalleryStory): GalleryDataStorage[] {
  return isDataStory(story) ? story.storage : [];
}

export function defineGalleryStory<TStory extends GalleryStory>(story: TStory): TStory {
  return story;
}

export function defineGalleryDataStory<TStory extends GalleryDataStory>(story: TStory): TStory {
  return story;
}

export function defineGallerySection(section: GallerySection): GallerySection {
  return section;
}
